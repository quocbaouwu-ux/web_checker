// Cloudflare Worker: chuyển mọi yêu cầu (trang + /api) về VPS qua địa chỉ tunnel đã đăng ký.
// Cần: KV binding tên STORE, secret tên SECRET.
const json = (obj, status) =>
  new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json" } });
const down = (isApi, status) => {
  const msg = "Máy chủ đang tắt, thử lại sau.";
  return isApi
    ? json({ error: msg }, status)
    : new Response(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:system-ui;padding:24px"><h3>${msg}</h3>`,
        { status, headers: { "content-type": "text/html; charset=utf-8" } });
};

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // VPS gọi vào đây để báo địa chỉ tunnel hiện tại
    if (url.pathname === "/register" && request.method === "POST") {
      if (request.headers.get("X-Secret") !== env.SECRET) return new Response("forbidden", { status: 403 });
      let backend = "";
      try { backend = (await request.json()).url || ""; } catch (e) {}
      if (!/^https:\/\/[a-z0-9-]+\.trycloudflare\.com$/.test(backend)) return new Response("bad url", { status: 400 });
      await env.STORE.put("backend", backend);
      return new Response("ok");
    }

    const isApi = url.pathname.startsWith("/api/");
    const backend = await env.STORE.get("backend");
    if (!backend) return down(isApi, 503);
    try {
      const resp = await fetch(backend + url.pathname + url.search, {
        method: request.method,
        headers: { "content-type": request.headers.get("content-type") || "application/json" },
        body: ["GET", "HEAD"].includes(request.method) ? undefined : await request.text(),
      });
      return new Response(resp.body, {
        status: resp.status,
        headers: { "content-type": resp.headers.get("content-type") || "text/plain", "cache-control": "no-store" },
      });
    } catch (e) {
      return down(isApi, 502);
    }
  },
};
