import json, re, subprocess, sys, time, urllib.request

WORKER_URL = "https://docmail.quocbaouwu.workers.dev"
SECRET = "DOI-CHUOI-BI-MAT-NAY"      # phải trùng với secret SECRET đặt trong Worker
CLOUDFLARED = "cloudflared"          # hoặc đường dẫn đầy đủ tới cloudflared.exe
PORT = 5000


def register(url):
    req = urllib.request.Request(
        WORKER_URL + "/register", data=json.dumps({"url": url}).encode(),
        headers={"Content-Type": "application/json", "X-Secret": SECRET}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            print("Đã báo địa chỉ cho Worker:", url, "->", r.status)
    except Exception as e:
        print("Báo địa chỉ thất bại:", e)


def start_app():
    return subprocess.Popen([sys.executable, "app.py"])


app = start_app()
while True:
    if app.poll() is not None:
        print("app.py đã dừng, chạy lại...")
        app = start_app()
    tun = subprocess.Popen(
        [CLOUDFLARED, "tunnel", "--url", f"http://localhost:{PORT}"],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
    for line in tun.stdout:
        m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
        if m:
            register(m.group(0))
    print("Tunnel đã dừng, chạy lại sau 5 giây...")
    time.sleep(5)
